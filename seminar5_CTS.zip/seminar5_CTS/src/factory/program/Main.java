package factory.program;

import factory.clase.*;

public class Main {
    public static void main(String[] args) {
        IFactory factory= PreparatFactory.getInstance(3);
        IPreparat paste= factory.crearePreparat(TipPreparat.PASTE,"paste tip A");
        IPreparat pizza1=factory.crearePreparat(TipPreparat.PIZZA,"pazza  tip AA");
        IPreparat pizza2=factory.crearePreparat(TipPreparat.PIZZA,"pazza  tip AA");

        paste.afisare();
        pizza1.afisare();
        pizza2.afisare();

        IPreparat pizza3=factory.crearePreparat(TipPreparat.PIZZA,"pazza  tip AA");
        IFactory factory2=PreparatFactory.getInstance(5);
        IPreparat pizza4=factory2.crearePreparat(TipPreparat.PIZZA,"pazza  tip AA");
        pizza4.afisare();

    }
}