package factory.clase;

public interface IPreparat {
    int getId();
    String getDenumire();

    void afisare();

}
