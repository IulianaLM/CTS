package factory.clase;

public interface IFactory {

    IPreparat crearePreparat(TipPreparat tipPreparat,String denumire);
}
