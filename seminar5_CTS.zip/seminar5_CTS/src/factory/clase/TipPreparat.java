package factory.clase;

public enum TipPreparat {
    PASTE,PIZZA
}
