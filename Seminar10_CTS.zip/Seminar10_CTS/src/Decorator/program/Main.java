package Decorator.program;

import Decorator.clase.AbsDecorator;
import Decorator.clase.Bon;
import Decorator.clase.DecoratorFebruarie;
import Decorator.clase.IBon;

public class Main {
    public static void main(String[] args) {
        //inainte de Decorator
        Bon bon1= new Bon("05.03.2025",28);
        bon1.printare();

        //dupa Decorator
        IBon bon2= new Bon("05.05.2025",351);
        IBon decoratorFebruarie= new DecoratorFebruarie(bon2);
        decoratorFebruarie.printare();
    }
}