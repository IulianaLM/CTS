package Decorator.clase;

public abstract class AbsDecorator implements IBon {
    protected IBon bon;
    public AbsDecorator(IBon bon){
        this.bon= bon;
    }

    @Override
    public void printare() {
        bon.printare();
    }

    @Override
    public String getData() {
        return bon.getData();
    }

    @Override
    public double getSuma() {
        return bon.getSuma();
    }
}
