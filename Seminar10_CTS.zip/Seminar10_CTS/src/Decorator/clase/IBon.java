package Decorator.clase;

import java.util.Date;

public interface IBon {
    public void printare();
    public String getData();
    public double getSuma();

}
