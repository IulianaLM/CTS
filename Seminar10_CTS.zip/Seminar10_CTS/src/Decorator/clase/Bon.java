package Decorator.clase;

public class Bon implements IBon{
    private String data;
    private float suma;

    @Override
    public void printare() {
        System.out.println("Se printeaza bonul din data "+ this.data+ ", in valoare de "+this.suma+" lei");

    }

    @Override
    public String getData() {
        return this.data;
    }

    public Bon(String data, float suma) {
        this.data = data;
        this.suma = suma;
    }

    @Override
    public double getSuma() {
        return this.suma;
    }
}
