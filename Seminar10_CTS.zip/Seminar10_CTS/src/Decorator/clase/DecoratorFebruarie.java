package Decorator.clase;

public class DecoratorFebruarie extends AbsDecorator{
    public DecoratorFebruarie(IBon bon) {
        super(bon);
    }

    @Override
    public double getSuma() {
        return super.getSuma();
    }

    @Override
    public void printare() {
        int contor= (int)super.getSuma()/100;
        for(int i=1;i<=contor;i++){
            System.out.println("<3");
        }
        super.printare();
    }
}
