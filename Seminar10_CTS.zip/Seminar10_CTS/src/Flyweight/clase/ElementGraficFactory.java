package Flyweight.clase;

import java.util.HashMap;
import java.util.Map;

public class ElementGraficFactory {
    public static Map<TipGrafic,IElementGrafic> mapa= new HashMap<>();
    static{
        mapa.put(TipGrafic.AVION,new ElementGrafic(TipGrafic.AVION,"detalii avion"));
        mapa.put(TipGrafic.NAVA,new ElementGrafic(TipGrafic.NAVA,"detalii nava"));
        mapa.put(TipGrafic.ASTEROID,new ElementGrafic(TipGrafic.ASTEROID,"detalii asteroid"));

    }
    public static IElementGrafic getElementGrafic(TipGrafic tipGrafic){
        return mapa.get(tipGrafic);
    }
}
