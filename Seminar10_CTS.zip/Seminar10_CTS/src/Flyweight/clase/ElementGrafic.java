package Flyweight.clase;

public class ElementGrafic implements IElementGrafic{
    private TipGrafic tip;
    private String detaliiDesenare;

    public ElementGrafic(TipGrafic tip, String detaliiDesenare) {
        this.tip = tip;
        this.detaliiDesenare = detaliiDesenare;
    }

    @Override
    public void deseneaza(int x, int y) {
        System.out.println("Se deseneaza "+this.tip+" cu cordonatele: ("+ x +","+y+")");
    }
}
