package Flyweight.clase;

public interface IElementGrafic {
    public void deseneaza(int x, int y);
}
