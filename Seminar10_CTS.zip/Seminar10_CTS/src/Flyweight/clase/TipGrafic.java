package Flyweight.clase;

public enum TipGrafic {
    NAVA,AVION,ASTEROID
}
