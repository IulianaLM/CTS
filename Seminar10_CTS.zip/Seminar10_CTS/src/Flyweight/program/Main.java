package Flyweight.program;

import Flyweight.clase.*;

public class Main {
    public static void main(String[] args) {
        ElementGraficFactory.getElementGrafic(TipGrafic.ASTEROID).deseneaza(10,2);
        Canvas canvas = new Canvas();
        canvas.addElementGrafic(TipGrafic.AVION,10,20);
        canvas.addElementGrafic(TipGrafic.AVION,10,30);
        canvas.addElementGrafic(TipGrafic.AVION,20,10);

        canvas.afisareCoordonate();



    }
}
